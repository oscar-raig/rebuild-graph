#! /bin/bash
echo
./anaxls t swws-inipy.txt
echo
./anaxls t swws-inipy0.txt.res
echo
./anaxls t swws-inipy1.txt.res
echo
./anaxls t swws-inipy2.txt.res
echo
./anaxls t swws-inipy3.txt.res
echo
./anaxls t swws-inipy4.txt.res
echo
./anaxls t swws-inipy5.txt.res
echo
./anaxls t swws-inipy6.txt.res
echo
./anaxls t swws-inipy7.txt.res
echo
./anaxls t swws-inipy8.txt.res
echo
./anaxls t swws-inipy9.txt.res
echo






