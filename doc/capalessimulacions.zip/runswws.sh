#! /bin/bash
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  12  --seed_y  13 --seed_z  14
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  15  --seed_y  16 --seed_z  17
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  18  --seed_y  19 --seed_z  20
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  21  --seed_y  22 --seed_z  23
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  24  --seed_y  25 --seed_z  26
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  27  --seed_y  28 --seed_z  29
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  30  --seed_y  31 --seed_z  32
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  33  --seed_y  34 --seed_z  35
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  36  --seed_y  37 --seed_z  38
time ./rebuild_graph  --graphFile ../example_graphs/swws-inipy.txt --algorithm 2 --k 0.95 --To 500 --TMin 0.00001 --nMax 2000  --output-format-adjlist --seed_x  39  --seed_y  40 --seed_z  41




